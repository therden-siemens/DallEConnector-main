//>>built
define("dijit/form/nls/bs/Textarea",{iframeEditTitle:"područje uređivanja",iframeFocusTitle:"okvir područja uređivanja"});
