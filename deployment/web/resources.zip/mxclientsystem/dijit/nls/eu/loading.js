//>>built
define("dijit/nls/eu/loading",{loadingState:"Kargatzen...",errorState:"Barkatu, errorea gertatu da"});
