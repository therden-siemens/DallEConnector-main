//>>built
define("dijit/layout/AccordionPane",["dojo/_base/declare","dojo/_base/kernel","./ContentPane"],function(_1,_2,_3){
return _1("dijit.layout.AccordionPane",_3,{constructor:function(){
_2.deprecated("dijit.layout.AccordionPane deprecated, use ContentPane instead","","2.0");
},onSelected:function(){
}});
});
